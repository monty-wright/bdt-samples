#!/bin/bash
SCRIPTPATH="$( cd -- "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
BDT_HOME="$(dirname "$SCRIPTPATH")"
populatePF="-f"
argc=$#
argv=("$@")

j=0
while [ $j -lt $argc ]
do
    if [ ${argv[j]} = $populatePF ]
    then 
	    $BDT_HOME/bin/config.sh 
            break
    fi
    j=$(( j + 1 ))
done
java -Dlog4j.configurationFile=file:"$BDT_HOME/conf/log4j2.properties"  -Dbdt.home="$BDT_HOME" -cp "$BDT_HOME/lib/*:$CLASSPATH"  com.vormetric.bdt.cli.BDTCli "$@"
