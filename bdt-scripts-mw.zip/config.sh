#!/bin/bash
set -x 

SCRIPTPATH="$( cd -- "$(dirname "$0")" >/dev/null 2>&1 ; pwd -P )"
BDT_HOME="$(dirname "$SCRIPTPATH")"

getparamvalue()
{
  PARAMVALUE=`grep "^${PARAMKEY}=" $CONFIGFILE | awk -F= '{print $2}'`
}
setparamvalue()
{
  rm -f $CONFIGFILENEW

  if [ $? -ne 0 ]
  then
    echo "Failure: error deleting temporary property file"
    exit 1
  fi

  mv -f $CONFIGFILE $CONFIGFILENEW 

  if [ $? -ne 0 ]
  then
    echo "Failure: error renaming property file"
    exit 1
  fi

  # Escape any slashes if the PARAMVALUE is a path
  PARAMVALUETEMP=`echo $PARAMVALUE | sed "s/\//~~\//g"`
  PARAMVALUEESC=`echo $PARAMVALUETEMP | sed "s/~~/\\\\\/g"`

  sed  "s/^${PARAMKEY}=.*$/${PARAMKEY}=${PARAMVALUEESC}/g" $CONFIGFILENEW > $CONFIGFILE 

  if [ $? -ne 0 ]
  then
    echo "Failure: error changing property value"
    exit 1
  fi

  rm -f $CONFIGFILENEW
  if [ $? -ne 0 ]
  then
    echo "Failure: error deleting temporary property file"
    exit 1
  fi
}


# edit bdt.properties file
CONFIGFILE=${BDT_HOME}/conf/bdt.properties
CONFIGFILENEW=${CONFIGFILE}_$$.temp;

#
# NAE IP
#
PARAMKEY=NAE_IP.1
PARAMVALUE=0
getparamvalue
NAE_IP=$PARAMVALUE

if [ -z "$NAE_IP" ]
then
  read -p " Enter the IP Address of the Cipher Manager : " TMP_NAE_IP
else
  read -p " Enter the IP Address of the Cipher Manager $NAE_IP: " TMP_NAE_IP
fi

if [ "x$TMP_NAE_IP" != "x" ]
then
  NAE_IP=$TMP_NAE_IP
fi

# set value of NAE_IP 
PARAMVALUE=$NAE_IP
setparamvalue

#
# NAE Port 
#
PARAMKEY=NAE_Port
getparamvalue
NAE_PORT=$PARAMVALUE

if [ -z "$NAE_PORT" ]
then
   read -p " Enter the Port of the CipherTrust Manager: " TMP_NAE_PORT
else
   read -p " Enter the Port of the CipherTrust Manager $NAE_PORT: " TMP_NAE_PORT
fi

if [ "x$TMP_NAE_PORT" != "x" ]
then
  NAE_PORT=$TMP_NAE_PORT
fi

# set value of NAE_Port
PARAMVALUE=$NAE_PORT
setparamvalue

#
# Log File
#
done=0
while [ $done -lt 1 ]
do
  PARAMKEY=Log_File
  getparamvalue
  LOG_FILE=$PARAMVALUE

  if [ -z "$LOG_FILE" ]
  then
    read -p " Enter the full path for your Log File: " TMP_LOG_FILE
  else
    read -p " Enter the full path for your Log File $LOG_FILE: " TMP_LOG_FILE
  fi

  if [ "x$TMP_LOG_FILE" != "x" ]
  then
    LOG_FILE=$TMP_LOG_FILE
  fi
  
  if [ "x$LOG_FILE" = "x" ]
  then
     done=0
  else
     touch $LOG_FILE 2>/dev/null
     if [ -f $LOG_FILE ]
     then
         done=1
     else
         done=0
         echo "Invalid log file path."
      fi
  fi
done

#check for absoulate path of the log file
case "$LOG_FILE" in
/*) PARAMVALUE=$LOG_FILE ;;
*) PARAMVALUE=`pwd`/$LOG_FILE ;;
esac

setparamvalue
#End of Log File 
